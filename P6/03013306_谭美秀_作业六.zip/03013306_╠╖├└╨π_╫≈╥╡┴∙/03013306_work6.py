# -*- coding: utf-8 -*-

import matplotlib.pyplot as plt
import numpy as np
import math
from  statistics import mean,stdev,pstdev,variance,pvariance

from prettytable import PrettyTable

def getData_TextFile(filename):
    eachgroupitems=11
    curgroupitem=0
    xygroups=[]
    xy={'x':[],'y':[]}
    file=open(filename,'r')
    for line in file:
       
        x,y= line.split()
        xy['x'].append(float(x))
        xy['y'].append(float(y))

        curgroupitem +=1
        if curgroupitem== eachgroupitems:
            xygroups.append(xy)
            curgroupitem=0
            xy={'x':[],'y':[]}

    file.close()
    
    return xygroups


def satData(x,y):
    xsta={'avg':None,'stdev':None,'pstdev':None,'var':None,'pvar':None}
    ysta={'avg':None,'stdev':None,'pstdev':None,'var':None,'pvar':None}

    xsta['avg']=mean(x)
    ysta['avg']=mean(y)

    xsta['stdev']=stdev(x)
    ysta['stdev']=stdev(y)

    xsta['pstdev']=pstdev(x)
    ysta['pstdev']=pstdev(y)

    xsta['var']=variance(x)
    ysta['var']=variance(y)

    xsta['pvar']=pvariance(x)
    ysta['pvar']=pvariance(y)

    r=np.corrcoef(x,y)[0, 1]

    return  xsta,ysta,r

def fitData(x,y):
    #find linear fit
    a,b = np.polyfit(x,y,1)
    predictedY = a*np.array(x) + b
    
    return a,b,predictedY


def plotData(x,y,a,b, predictedY,i):
    plt.plot(x,y, 'bo')

    plt.title("fileName""%0f" % i)
    plt.xlabel('x')
    plt.ylabel('y')

    plt.plot(x,predictedY,
               label = 'Y by\nlinear fit, y = '
               + str(round(a, 5))+'*x+'+str(round(b, 5)))

    plt.legend(loc = 'best')
    


#main


xygroups = getData_TextFile('Data.txt')

print("data_number:")
print(len(xygroups)) 

print("the original data:")
for i  in  range(len(xygroups)):
        print(xygroups[i])
        
        
table = PrettyTable(["data set",
                         "x-avg", "x-std", "x-pstd", "x-var","x-pvar",
                         "y-avg", "y-std", "y-pstd", "y-var","y-pvar",
                         "pearson_r"])  
       
       
figcount=len(xygroups)
figcol=2
figrow=math.ceil(figcount/figcol)
fig=plt.figure(figsize=(12.0,8.0))
fig.subplots_adjust(left=0.05,right=0.95,bottom=0.05,top=0.95)

       
for i in range(len(xygroups)):
        xsta,ysta,r=satData(xygroups[i]['x'], xygroups[i]['y'])
        a,b,predictedY=fitData(xygroups[i]['x'], xygroups[i]['y'])

        fig.add_subplot(figrow, figcol,i+1)     #子图
        
        plotData(xygroups[i]['x'],xygroups[i]['y'],
                 a,b,predictedY,i)


        table.add_row(["file" "%.0f" % i,
                   "%.3f" % xsta['avg'],
                   "%.3f" % xsta['stdev'],"%.3f" %xsta['pstdev'],
                   "%.3f" % xsta['var'],"%.3f" % xsta['pvar'],
                   "%.3f" % ysta['avg'],
                   "%.3f" % ysta['stdev'],"%.3f" % ysta['pstdev'],
                   "%.3f" % ysta['var'],"%.3f" % ysta['pvar'],
                   "%.3f" % r])


print(table)

plt.show()  
      





        

