# -*- coding: utf-8 -*-

import math
import numpy as np
import matplotlib.pyplot as plt
from  statistics import mean,stdev,pstdev,variance,pvariance

import glob
from prettytable import PrettyTable


filenames=[]

xygroup=[]

stagroup=[]
rgroup=[]

lfit=[]

def getData_TextFile(fileName):

    dataFile = open(fileName, 'r')

    xy={'x':[],'y':[]}

    discardHeader = dataFile.readline()

    for line in dataFile:
        x,y= line.split()
        xy['x'].append(float(x))
        xy['y'].append(float(y))

    dataFile.close()

    return xy

def staData(d):
    dsta={}
    dsta['avg']=mean(d)
    dsta['stdev']=stdev(d)
    dsta['pstdev']=pstdev(d)
    dsta['var']=variance(d)
    dsta['pvar']=pvariance(d)
    return  dsta

def staDataDict(ddict):
    sta={}
    for (k,v) in ddict.items():
        sta[k]=staData(v)
       
    r=np.corrcoef(ddict['x'],ddict['y'])[0, 1]

    return  sta,r

def fitData(x,y):
    """ linear fit """
    a,b = np.polyfit(x,y,1)
    predictedY = a*np.array(x) + b
    return a,b,predictedY

def plotData(x,y,a,b, predictedY,fileName):
    plt.plot(x,y, 'bo',
               label= fileName)

    plt.title(fileName)
    plt.xlabel('x')
    plt.ylabel('y')

    plt.plot(x,predictedY,
               label = 'Y by\nlinear fit, y = '
               + str(round(a, 5))+'*x+'+str(round(b, 5)))

    plt.legend(loc = 'best')

def processing_one_TextFile(filename):

    xy=getData_TextFile(filename)

    sta,r=staDataDict(xy)

    a,b,predictedY=fitData(xy['x'],xy['y'])

    return xy,sta,r,a,b,predictedY

def processing_data_TextFiles(filenames):

    for i in range(len(filenames)):

        xy,sta,r,a,b,predictedY =processing_one_TextFile(filenames[i])

        xygroup.append(xy)

        stagroup.append(sta)
      
        rgroup.append(r)

        lfit.append({'a':a,'b':b,'preY':predictedY})

def processing_plot_TextFiles(filenames):

    fig=plt.figure(figsize=(12.0,8.0))

    fig.subplots_adjust(left=0.05,right=0.95,bottom=0.05,top=0.95)

    figcount=len(filenames)

    figcol=2
    figrow=math.ceil(figcount/figcol)

    for i in range(figcount):
        fig.add_subplot(figrow, figcol,i+1)
        plotData(xygroup[i]['x'],xygroup[i]['y'],
                 lfit[i]['a'],lfit[i]['b'],lfit[i]['preY'],filenames[i])

    plt.show()

def processing_table_TextFiles(filenames):

    table = PrettyTable(["data set",
                         "x-avg", "x-std", "x-pstd", "x-var","x-pvar",
                         "y-avg", "y-std", "y-pstd", "y-var","y-pvar",
                         "pearson_r"])

    table.align= "r" 
    table.padding_width = 1
   
    for i in range(len(filenames)):
        table.add_row(
                 [
                  filenames[i],
                   "%.3f" % stagroup[i]['x']['avg'],
                   "%.3f" % stagroup[i]['x']['stdev'],"%.3f" %stagroup[i]['x']['pstdev'],
                   "%.3f" % stagroup[i]['x']['var'],"%.3f" % stagroup[i]['x']['pvar'],
                   "%.3f" % stagroup[i]['y']['avg'],
                   "%.3f" % stagroup[i]['y']['stdev'],"%.3f" % stagroup[i]['y']['pstdev'],
                   "%.3f" % stagroup[i]['y']['var'],"%.3f" % stagroup[i]['y']['pvar'],
                   "%.3f" % rgroup[i]
                ])
    print(table)

if __name__ == '__main__':

    filenames=glob.glob(r'./Anscombe*.txt')
 
    processing_data_TextFiles(filenames)
    processing_table_TextFiles(filenames)
    processing_plot_TextFiles(filenames)
