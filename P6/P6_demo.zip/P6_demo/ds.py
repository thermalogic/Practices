xytables=[]
count=4
for i in range(count):
    xytables.append({'x':[],'y':[]})
