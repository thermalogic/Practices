
/* Search an array for a key using Binary Search */

#ifndef BSEARCH_H
#define BSEARCH_H


int bSearch(const int a[], int size, int key);

#endif