/*
 * region4.h
 *
 *  Created on: 2017年5月18日
 *      Author: dell
 */

#ifndef REGION4_H
#define REGION4_H

/* 
 -1  p t
 -1  1 1 
*/ 
#define INVALID_T   -110
#define INVALID_P   -101
#define INVALID_PT  -100

const double Tc = 647.096;

double _PSat_T(double T);
double _TSat_P(double P);

#endif /* REGION4_H */
