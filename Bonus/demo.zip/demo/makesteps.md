# Linux

## Build so and test

```bash
$make -f makefile-linux
```

## Build so,test and run
```bash
$make run -f makefile-linux
```

# Windows

## Build dll and test

```bash
>make -f makefile-win
```
## Build dll,test and run
```bash
>make run -f makefile-win
```