/*
 * test4.c
 *
 *  Created on: 2017年5月18日
 *      Author: dell
 */
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "../include/region4.h"

int main()
{
	printf("\nTest double _TSat_P(double P)\n");
	double p = 0.1;
	double t1 = _TSat_P(p);
	printf("\t p= %f ,t1=  %f", p, t1);
	if (fabs(t1 - 0.372755919e3) < 1e-5)
		printf(" True");
	else
		printf(" False");


	printf("\nTest double _PSat_T(double T)");
	double T[] = {300,500,600,700,200};
	double pi[]={0.353658941e-2,0.263889776e1,0.123443146e2,-110,-110};
    for(int i=0; i<5; i++)
	{    
	  double p1 = _PSat_T(T[i]);
	  printf("\n\t T= %f ,p=  %f", T[i], p1);
	  if (p1==INVALID_T)
      {
		printf("\tINVALID_T");
	  }
	  else
	  {
	    if (fabs(p1 - pi[i]) < 1e-5)
	 	    printf(" True");
  	     else
		    printf("False");
	   };
	};	
	
	return 0;
}
