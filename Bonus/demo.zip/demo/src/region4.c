/*
 * region4.c
 *
 *  Created on: 2017年5月18日
 *      Author: dell
 */

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "../include/region4.h"
// Region 4
// Saturated line
double _PSat_T(double T)
{
	if (T < 273.15 || T > Tc)
	{
		return INVALID_T;
	}

	double n[] = {0, 0.11670521452767E+04, -0.72421316703206E+06, -0.17073846940092E+02,
				  0.12020824702470E+05, -0.32325550322333E+07, 0.14915108613530E+02,
				  -0.48232657361591E+04, 0.40511340542057E+06, -0.23855557567849E+00,
				  0.65017534844798E+03};
	double tita = T + n[9] / (T - n[10]);
	double A = pow(tita, 2) + n[1] * tita + n[2];
	double B = n[3] * pow(tita, 2) + n[4] * tita + n[5];
	double C = n[6] * pow(tita, 2) + n[7] * tita + n[8];
	double P = pow(2 * C / (-B + pow((pow(B, 2) - 4 * A * C), 0.5)), 4);
	if (P < 611.212677 / 1e6 || P > 22.064)
	{
		return INVALID_P;
	}
	return P;
}

double _TSat_P(double P)
{
	if (P < 611.212677 / 1e6 || P > 22.064)
	{
		return INVALID_P;
	}
	double n[] = {0, 0.11670521452767E+04, -0.72421316703206E+06, -0.17073846940092E+02,
				  0.12020824702470E+05, -0.32325550322333E+07, 0.14915108613530E+02,
				  -0.48232657361591E+04, 0.40511340542057E+06, -0.23855557567849E+00,
				  0.65017534844798E+03};
	double beta = pow(P, 0.25);
	double E = pow(beta, 2) + n[3] * beta + n[6];
	double F = n[1] * pow(beta, 2) + n[4] * beta + n[7];
	double G = n[2] * pow(beta, 2) + n[5] * beta + n[8];
	double D = 2 * G / (-F - pow((pow(F, 2) - 4 * E * G), 0.5));
	double T = (n[10] + D - pow((pow(n[10] + D, 2) - 4 * (n[9] + n[10] * D)), 0.5)) / 2;
	if (T < 273.15 || T > Tc)
	{
	    return INVALID_T;
	}

	return T;
}
