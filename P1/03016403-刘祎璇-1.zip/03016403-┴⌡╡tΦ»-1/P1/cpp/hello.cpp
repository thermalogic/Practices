/*
g++ -o hello hello.cpp

./hello
*/
#include <iostream>
using namespace std;
 
int main() {
   cout << "      Name: "<<"Liu Yixuan"<<endl;
   cout << "Student ID: "<<"03016403"<<endl;
   return 0;
}