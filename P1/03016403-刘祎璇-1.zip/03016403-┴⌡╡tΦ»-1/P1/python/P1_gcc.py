# 节选
a = 1
print(a)
a = 0.1
print(a)
a = "Southeast University"
print(a)
# 输出学号和姓名
print('学号：03016403')
print('姓名：刘祎璇')
