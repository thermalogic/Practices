stu_ID='03016403'
stu_name='刘祎璇'
print('Student ID:',stu_ID)
print('Student name:',stu_name)
