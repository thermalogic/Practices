# -*- coding: UTF-8 -*-
'''
Created on 2016年5月16日

@author: Fyx
'''
import unittest
import if97_property_relation as ipr

class FirstExampleTestCase(unittest.TestCase):#第一至三次测试，测试三组if97物性公式
    def test_Pressure(self):
        self.assertEqual(ipr.Pressure(500, 650),25.583701818521682)
    def test_Specific_internal_energy(self):
        self.assertEqual(ipr.Specific_internal_energy(500, 650),1812.262786196376)
    def test_Specific_entropy(self):
        self.assertEqual(ipr.Specific_entropy(500, 650),4.054272733339388)
    def test_Specific_enthalpy(self):
        self.assertEqual(ipr.Specific_enthalpy(500, 650),1863.4301898334193)    
    def test_Specific_isobaric_heat_capacity(self):
        self.assertEqual(ipr.Specific_isobaric_heat_capacity(500, 650),13.893571744172052)
    def test_Speed_of_sound(self):
        self.assertEqual(ipr.Speed_of_sound(500, 650),502.0055537578271)
        
class SecondExampleTestCase(unittest.TestCase):
    def test_Pressure(self):
        self.assertEqual(ipr.Pressure(200, 650),22.293064256610883)
    def test_Specific_internal_energy(self):
        self.assertEqual(ipr.Specific_internal_energy(200, 650),2263.658684165079)
    def test_Specific_entropy(self):
        self.assertEqual(ipr.Specific_entropy(200, 650),4.85438791974196)
    def test_Specific_enthalpy(self):
        self.assertEqual(ipr.Specific_enthalpy(200, 650),2375.124005448133)
    def test_Specific_isobaric_heat_capacity(self):
        self.assertEqual(ipr.Specific_isobaric_heat_capacity(200, 650),44.657934155580364)
    def test_Speed_of_sound(self):
        self.assertEqual(ipr.Speed_of_sound(200, 650),383.444594204627)
               
class ThirdExampleTestCase(unittest.TestCase):
    def test_Pressure(self):
        self.assertEqual(ipr.Pressure(500, 750),78.30956391691684)
    def test_Specific_internal_energy(self):
        self.assertEqual(ipr.Specific_internal_energy(500, 750),2102.0693176264285)
    def test_Specific_entropy(self):
        self.assertEqual(ipr.Specific_entropy(500, 750),4.469719056216713)
    def test_Specific_enthalpy(self):
        self.assertEqual(ipr.Specific_enthalpy(500, 750),2258.6884454602623)       
    def test_Specific_isobaric_heat_capacity(self):
        self.assertEqual(ipr.Specific_isobaric_heat_capacity(500, 750),6.341653594791308)
    def test_Speed_of_sound(self):
        self.assertEqual(ipr.Speed_of_sound(500, 750),760.696040876796)
        
class FourthExampleTestCase(unittest.TestCase):#第四至六次测试，测试三组补充公式
    def test_Backward_Equation_3a(self):
        self.assertEqual(ipr.Backward_Equation_3a(20, 1700), 629.308389159384)
    def test_Backward_Equation_3b(self):
        self.assertEqual(ipr.Backward_Equation_3b(20, 2500), 641.8418053232451)
    
class FifthExampleTestCase(unittest.TestCase):
    def test_Backward_Equation_3a(self):
        self.assertEqual(ipr.Backward_Equation_3a(50, 2000), 690.5718337873052)  
    def test_Backward_Equation_3b(self):
        self.assertEqual(ipr.Backward_Equation_3b(50, 2400), 735.1848617922307)
           
class SixthExampleTestCase(unittest.TestCase):
    def test_Backward_Equation_3a(self):
        self.assertEqual(ipr.Backward_Equation_3a(100, 2100), 733.6163014455943)  
    def test_Backward_Equation_3b(self):
        self.assertEqual(ipr.Backward_Equation_3b(100, 2700), 842.046087633262)
            
if __name__ == '__main__':
    #unittest.main(defaultTest='suite_use_make_suite')
    #以下用于显示测试信息详情
    suite1 = unittest.TestLoader().loadTestsFromTestCase(FirstExampleTestCase)
    suite2 = unittest.TestLoader().loadTestsFromTestCase(SecondExampleTestCase)
    suite3 = unittest.TestLoader().loadTestsFromTestCase(ThirdExampleTestCase)
    suite4 = unittest.TestLoader().loadTestsFromTestCase(FourthExampleTestCase)
    suite5 = unittest.TestLoader().loadTestsFromTestCase(FifthExampleTestCase)
    suite6 = unittest.TestLoader().loadTestsFromTestCase(SixthExampleTestCase)
    allTests = unittest.TestSuite([suite1,suite2,suite3,suite4,suite5,suite6])#allTests
    unittest.TextTestRunner(verbosity=3).run(allTests)