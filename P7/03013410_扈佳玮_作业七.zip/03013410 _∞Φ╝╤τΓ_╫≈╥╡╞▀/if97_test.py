# -*- coding: UTF-8 -*-
import unittest
import seuif97

class Region1Test (unittest.TestCase):

    def setUp(self):
        self.k=273.15#温标转化

# Table 5 Page 9 ， p,t(K),h,s,v,u,cp,w
        self.tab5=[ [  3, 300, 0.115331273e3, 0.392294792,0.100215168e-2,0.112324818e3,0.417301218e1,0.150773921e4 ],
                [80, 300, 0.184142828e3, 0.368563852,0.971180894e-3,0.106448356e3,0.401008987e1,0.163469054e4],
                [  3, 500, 0.975542239e3, 0.258041912e1,0.120241800e-2,0.971934985e3,0.465580682e1,0.124071337e4]]#测试用数据

    def testSpecificEnthalpyPT(self):#测试一定压强下一定温度下的比焓
        places = 6#精度等级小数点后数位
        for item in  self.tab5:
            self.assertAlmostEqual(seuif97.pt(item[0], item[1]-self.k,4),item[2],places)

    def testSpecificEntropyPT(self):#测试一定压强下一定温度下的比熵
        places = 9
        for item in  self.tab5:
            self.assertAlmostEqual(seuif97.pt(item[0], item[1]-self.k,5),item[3],places)

    def testSpecificVPT(self):#测试一定压强下一定温度下的比容
        places = 11
        for item in  self.tab5:
            self.assertAlmostEqual(seuif97.pt(item[0], item[1]-self.k,3),item[4],places)

    def testSpecificUPT(self):#测试一定压强下一定温度下的内能
        places = 6
        for item in  self.tab5:
            self.assertAlmostEqual(seuif97.pt(item[0], item[1]-self.k,7),item[5],places)

    def testSpecificCPPT(self):#测试一定压强下一定温度下的定压比热容
        places = 8
        for item in  self.tab5:
            self.assertAlmostEqual(seuif97.pt(item[0], item[1]-self.k,8),item[6],places)

    def testSpecificWPT(self):#测试一定压强下一定温度下的声速
        places = 5
        for item in  self.tab5:
            self.assertAlmostEqual(seuif97.pt(item[0], item[1]-self.k,10),item[7],places)

class Region1TestBW (unittest.TestCase):

      def setUp(self):
          self.k=273.15
          self.tab7=[[3,500,0.391798509e3],
                   [80,500,0.378108626e3],
                   [80,1500,0.611041229e3]]#p,h,T
          self.tab9=[[3,0.5,0.307842258e3],
                   [80,0.5,0.309979785e3],[
                    80,3,0.565899909e3]]#p,h,T

      def testSpecificTemperaturePHtab7(self):# IF97数据测试一定压强下一定比焓下的温度
          places = 6
          for item in  self.tab7:
              self.assertAlmostEqual(seuif97.ph(item[0], item[1],1),item[2]-self.k,places)

      def testSpecificTemperaturePH(self):# 一致性测试
          places = 6
          for item in  self.tab7:
              p=item[0]
              t=item[2]-self.k
              h=seuif97.pt2h(p,t)
              self.assertAlmostEqual(seuif97.ph2t(p, h),t,places)

      def testSpecificTemperaturePStab9(self):# IF97数据 测试一定压强下一定比熵下的温度
          places = 6
          for item in  self.tab9:
              self.assertAlmostEqual(seuif97.ps(item[0], item[1],1),item[2]-self.k,places)

      def testSpecificTemperaturePS(self):# 一致性测试 
          places = 6
          for item in  self.tab9:
              p=item[0]
              t=item[2]-self.k
              s=seuif97.pt2s(p,t)
              self.assertAlmostEqual(seuif97.ps2t(p, s),t,places)
            
def suitetext():
    suite = unittest.TestSuite()
    suite.addTest(unittest.makeSuite(Region1Test))
    suite.addTest(unittest.makeSuite(Region1TestBW))
    return suite

if __name__ == '__main__':
    unittest.main()(defaultTest = 'suite')
