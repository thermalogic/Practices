# -*- coding: utf-8 -*-

xygroup=[]

def getData_TextFile(fileName):

    datafile = open(fileName, 'r')

    title = datafile.readline()
    groups=len(title.split())//2
    for line in datafile:
        curline= line.split()
        for i in range(groups):
           xy={'x':[],'y':[]}
           xygroup.append(xy)
           xygroup[i]['x'].append(float(curline[i*2]))
           xygroup[i]['y'].append(float(curline[i*2+1]))
      
    datafile.close()

    return xygroup

if __name__ == '__main__':
    xygroup=getData_TextFile('xydata.txt')
    print(xygroup[0]['x'])
    print(xygroup[2]['y'][1:3])
  
