# -*- coding: UTF-8 -*-

import numpy as np
import matplotlib.pyplot as plt
from prettytable import PrettyTable
    
def get_temperaturegrid():
    """ get temperature grid """ 
    m=4 # row
    n=4 # col 

    # wall:
    #  col 0 left，n right
    node = np.zeros((m,n))
    #  row 0 top
    node[0,1],node[0,2]=500,500
    #  row m-1 bottom
    node[3,1],node[3,2]=100,100
    # left col 0
    node[1,0],node[2,0]=100,100
    # right n-1 
    node[1,3],node[2,3]=100,100

    a = np.array([
              [4,-1,-1,0],
              [-1,4,0,-1],
              [-1,0,4,-1],
              [0,-1,-1,4] 
             ])
    b = np.array([
             node[0,1]+node[1,0],
             node[0,2]+node[1,3],
             node[2,0]+node[3,1],
             node[2,3]+node[3,2]
             ]
             )
    t = np.linalg.solve(a, b)
 
    temperature=np.zeros((2,2))
    
    for i in range(2):
        temperature[i,0],temperature[i,1]= t[2*i],t[2*i+1]
 
    return temperature

def print_temperaturegrid(t):
    """ print temperature grid """  
    table = PrettyTable(["0","1"])  
    table.align= "c" #居中
    table.padding_width = 1 #One space between column edges and contents (default)
    for i in range(2):
        table.add_row([t[i,0],t[i,1]])
    print(table)

def plot_temperaturegrid(t):
    """ plot temperature grid """ 
    plt.imshow(temperature,interpolation='bilinear', cmap=plt.get_cmap("coolwarm"))
    plt.colorbar()
    plt.show()

temperature=get_temperaturegrid() 
print_temperaturegrid(temperature)
plot_temperaturegrid(temperature)
