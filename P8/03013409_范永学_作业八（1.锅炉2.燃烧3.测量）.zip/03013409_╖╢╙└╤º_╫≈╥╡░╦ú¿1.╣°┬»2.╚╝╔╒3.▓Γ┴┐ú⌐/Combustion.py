# -*- coding: UTF-8 -*-
'''
Created on 2016年5月22日

@author: fyx
'''
#燃烧学中常用气体导热系数、粘性系数温度关系式计算
n=float(input("choose the number(1-CH4,2-C2H6,3-C3H8,4-C4H10,6-C6H14,7-C7H16,8-C8H18):"))#选择所要查询的气体编号
T=float(input("T:"))#输入温度

def thermal_conductivity(a):#计算常用气体导热系数
    Lambda=0
    for i in range(0,7):
        Lambda+=a[i]*T**i
    print('Lambda=',Lambda,'W/(m*K)')

def coefficient_of_viscosity(b):#计算常用气体粘性系数
    sum=0
    for i in range(0,7):
        sum+=b[i]*T**i
    Mu=sum/1000000
    print('Mu=',Mu,'N*s/m2')

def Combustion1(fileName):#从导热系数温度关系式系数表读取并计算
    dataFile = open(fileName, 'r')
    C1C2C3C4C6C7C8={'C1':[],'C2':[],'C3':[],'C4':[],'C6':[],'C7':[],'C8':[]}
    discardHeader = dataFile.readline()
    for line in dataFile:
        CH4,C2H6,C3H8,C4H10,C6H14,C7H16,C8H18= line.split()
        C1C2C3C4C6C7C8['C1'].append(float(CH4))
        C1C2C3C4C6C7C8['C2'].append(float(C2H6))
        C1C2C3C4C6C7C8['C3'].append(float(C3H8))
        C1C2C3C4C6C7C8['C4'].append(float(C4H10))
        C1C2C3C4C6C7C8['C6'].append(float(C6H14))
        C1C2C3C4C6C7C8['C7'].append(float(C7H16))
        C1C2C3C4C6C7C8['C8'].append(float(C8H18))
    dataFile.close()
    if n==1:
        thermal_conductivity(C1C2C3C4C6C7C8['C1'])
    elif n==2:
        thermal_conductivity(C1C2C3C4C6C7C8['C2']) 
    elif n==3:
        thermal_conductivity(C1C2C3C4C6C7C8['C3'])
    elif n==4:
        thermal_conductivity(C1C2C3C4C6C7C8['C4'])
    elif n==6:
        thermal_conductivity(C1C2C3C4C6C7C8['C6'])
    elif n==7:
        thermal_conductivity(C1C2C3C4C6C7C8['C7'])
    elif n==8:
        thermal_conductivity(C1C2C3C4C6C7C8['C8'])
        
def Combustion2(fileName):#从粘性系数温度关系式系数表读取并计算
    dataFile = open(fileName, 'r')
    C1C2C3C4C6C7C8={'C1':[],'C2':[],'C3':[],'C4':[],'C6':[],'C7':[],'C8':[]}
    discardHeader = dataFile.readline()
    for line in dataFile:
        CH4,C2H6,C3H8,C4H10,C6H14,C7H16,C8H18= line.split()
        C1C2C3C4C6C7C8['C1'].append(float(CH4))
        C1C2C3C4C6C7C8['C2'].append(float(C2H6))
        C1C2C3C4C6C7C8['C3'].append(float(C3H8))
        C1C2C3C4C6C7C8['C4'].append(float(C4H10))
        C1C2C3C4C6C7C8['C6'].append(float(C6H14))
        C1C2C3C4C6C7C8['C7'].append(float(C7H16))
        C1C2C3C4C6C7C8['C8'].append(float(C8H18))
    dataFile.close()
    if n==1:
        coefficient_of_viscosity(C1C2C3C4C6C7C8['C1'])
    elif n==2:
        coefficient_of_viscosity(C1C2C3C4C6C7C8['C2']) 
    elif n==3:
        coefficient_of_viscosity(C1C2C3C4C6C7C8['C3'])
    elif n==4:
        coefficient_of_viscosity(C1C2C3C4C6C7C8['C4'])
    elif n==6:
        coefficient_of_viscosity(C1C2C3C4C6C7C8['C6'])
    elif n==7:
        coefficient_of_viscosity(C1C2C3C4C6C7C8['C7'])
    elif n==8:
        coefficient_of_viscosity(C1C2C3C4C6C7C8['C8'])
        
Combustion1(r'./Combustion1.txt')
Combustion2(r'./Combustion2.txt')
