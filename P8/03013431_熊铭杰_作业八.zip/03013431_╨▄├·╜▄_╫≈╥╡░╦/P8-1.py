# -*- coding: UTF-8 -*-
'''
@author: XMJ
'''

import math
from prettytable import PrettyTable


t1=[]
t2=[]
t3=[]
t4=[]


def GaussSeidel(t01,t02,t03,t04):
    t1.append((t01+t04)/2)
    t2.append(t1[0])
    t3.append((t03+t04)/2)
    t4.append(t3[0]);
    
    i=1
    while(1):
        t1.append((t01+t04+t2[i-1]+t3[i-1])/4)
        t2.append((t01+t02+t1[i]+t4[i-1])/4)
        t3.append((t03+t04+t1[i]+t4[i-1])/4)
        t4.append((t02+t03+t2[i]+t3[i])/4)
        if max(t1[i]-t1[i-1],t2[i]-t2[i-1],t3[i]-t3[i-1],t4[i]-t4[i-1])<2e-4: #精度要求[(t_i_k)-(t_i_k+1)]/(t_i_k)<=2*10^(-4)
            print('Iteration End')
            break
        else: #不满足精度要求继续迭代
            i+=1

def print_table():
    
    table = PrettyTable(["Number of iterations","t1","t2","t3","t4"])  
    table.align= "c" #居中
    table.padding_width = 1 #One space between column edges and contents (default)
    
    GaussSeidel(500,100,100,100)
    
    for j in range(0,len(t1)):
        table.add_row([j,"%.6f" % t1[j],"%.6f" % t2[j],"%.6f" % t3[j],"%.6f" % t4[j]])
    print(table)


print_table()