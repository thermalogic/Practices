# -*- coding: UTF-8 -*-
'''
@author: XMJ
'''
import matplotlib.pyplot as plt
import numpy as np
import math
from seuif97 import *
from prettytable import PrettyTable
import matplotlib.pyplot as plt 

fileName='high.txt'

fileData={'G':[],'t1':[],'p1':[],'delta_p':[],'Pi':[]}
#G表示级流量(T/h), t1表示级前温度, p1表示级前压力(MPa), delta_p表示全级压降(MPa), Pi表示内功率(kW)

h1=[] #级前焓(kJ/kg)
s1=[] #级前比熵(kJ/kg*k)
p2=[] #级后压力(MPa)
h2=[] #级后焓(kJ/kg)
delta_h=[] #理想焓降(kJ/kg)
delta_hi=[] #有效焓降(kJ/kg)
eta=[] #相对内效率
a=0 #重热系数


def getData(fileName):

    dataFile = open(fileName, 'r')
    
    discardHeader = dataFile.readline()

    for line in dataFile:
        n,G,t1,p1,delta_p,Pi= line.split()
        fileData['G'].append(float(G))
        fileData['t1'].append(float(t1))
        fileData['p1'].append(float(p1))
        fileData['delta_p'].append(float(delta_p))
        fileData['Pi'].append(float(Pi))

    dataFile.close()
    return fileData
 
    
def fitData(fileData):
    for i in range(0,12):
        h1.append(pt2h(fileData['p1'][i],fileData['t1'][i]))
        s1.append(pt2s(fileData['p1'][i],fileData['t1'][i]))
        p2.append(fileData['p1'][i]-fileData['delta_p'][i])
        h2.append(ps2h(p2[i], s1[i]))
        delta_h.append(h1[i]-h2[i])
        delta_hi.append(fileData['Pi'][i]/(fileData['G'][i]/3.6)) #需要将流量从T/h换算成kg/s
        eta.append(delta_hi[i]/delta_h[i])
    
    ht=ps2h(p2[11], s1[0])
    delta_ht_mac=h1[0]-ht
    sum=0 #∑delta_ht
    for i in range(0,12):
        sum+=delta_h[i]
    a = ( sum - delta_ht_mac ) / delta_ht_mac
    return a


def print_table():
    
    table = PrettyTable(["级号","级流量","级前温度","级前压力","级前焓","级前比熵","全级压差","级后压力","级后焓",
                         "内功率","理想焓降","有效焓降","相对内效率"])  
    table.align= "c" #居中
    table.padding_width = 1 #One space between column edges and contents (default)
    
    for i in range(0,12):
        table.add_row([i,"%.2f" % fileData['G'][i],"%.2f" % fileData['t1'][i],"%.2f" % fileData['p1'][i],
                       "%.2f" % h1[i],"%.2f" % s1[i],"%.3f" % fileData['delta_p'][i],
                       "%.2f" % p2[i],"%.2f" % h2[i],"%.2f" % fileData['Pi'][i],"%.2f" % delta_h[i],"%.2f" % delta_hi[i],"%.4f" % eta[i]])
    print(table)
    
    
getData(fileName)
a = fitData(fileData)
print_table()
print('\n','重热系数a为','\t',a)

#%matplotlib inline 

def autolabel(rects): #画柱状图
    for rect in rects:
        height = rect.get_height()
        plt.text(rect.get_x()+rect.get_width()/24, 1.03*height, "%.2f" % float(height))
    
plt.xlabel(u"Stage Number")
plt.ylabel(u"Relative Internal Efficiency")

rect = plt.bar(left = (1,2,3,4,5,6,7,8,9,10,11,12),color='b',
        height = (eta[0],eta[1],eta[2],eta[3],eta[4],eta[5],eta[6],eta[7],eta[8],eta[9],eta[10],eta[11]),
        width = 0.6,align="center")
    
plt.title(u"Relative Internal Efficiency of Turbine")
plt.xticks((1,2,3,4,5,6,7,8,9,10,11,12),(u"0",u"1",u"2",u"3",u"4",u"5",u"6",u"7",u"8",u"9",u"10",u"11"))
autolabel(rect)
plt.grid(True)
plt.show()
